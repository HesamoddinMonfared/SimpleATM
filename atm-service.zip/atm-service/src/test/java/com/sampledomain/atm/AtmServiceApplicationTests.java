package com.sampledomain.atm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtmServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
